from setuptools import setup

setup(
    name='packaging_tutorial',
    packages=['add', 'sub'],
    package_dir={'': 'src'}
)