def sub_one(num):
    return num - 1