def add_one(num):
    return num + 1